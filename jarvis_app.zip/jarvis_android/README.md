# J.A.R.V.I.S. - complete project (Android app + backend + automatic APK build)

Folders: app/ (Android app), backend/ (server), .github/workflows/build.yml (builds the APK for you).

## Get the app on your phone
1. Unzip this folder on a computer.
2. github.com > New repository > name "jarvis" > set **Private** > Create.
3. Click "uploading an existing file", drag in EVERYTHING inside the unzipped folder
   (including the hidden .github folder; on Mac press Cmd+Shift+. to show it), then Commit.
4. Host the backend on render.com: New > Web Service > connect the repo, then set
     Root Directory: backend
     Build Command:  pip install -r requirements.txt
     Start Command:  uvicorn server:app --host 0.0.0.0 --port $PORT
     Environment:    ANTHROPIC_API_KEY = your key
                     JARVIS_TOKEN      = a long random string (40+ characters)
   Copy the https address Render gives you.
5. In GitHub: repo > Settings > Secrets and variables > Actions > New repository secret:
     JARVIS_URL   = the Render address (no trailing slash)
     JARVIS_TOKEN = the same token as in Render
6. GitHub > Actions tab > "Build APK" > Run workflow. Wait about 5 minutes.
7. Open the finished run > Artifacts > jarvis-apk. Download it and unzip to get app-debug.apk.
8. On your phone, open app-debug.apk and allow "Install unknown apps". (Uninstall any older copy first.)

## First run
- Allow microphone, notifications and "Display over other apps".
- Settings > Accessibility > J.A.R.V.I.S. > on (only needed for tapping inside other apps).
- Settings > Battery > J.A.R.V.I.S. > Unrestricted.
- Say: "Jarvis, open Spotify".

## Turn it off
Say "Jarvis, shut down", tap POWER OFF in the app, or Settings > Apps > J.A.R.V.I.S. > Force stop.
Accessibility off: Settings > Accessibility > J.A.R.V.I.S.

## Notes
- The Render free plan sleeps when idle, so the first reply after a while can take about a minute.
- Never share the APK: it contains your token. To lock out a leaked APK, change JARVIS_TOKEN on Render.
- Emails are drafted in your mail app and you tap Send. Jarvis never taps pay, send, buy or delete.
