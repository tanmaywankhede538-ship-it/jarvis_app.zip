package com.example.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val http = OkHttpClient()
    private var awaitingCommand = false
    private var stopping = false
    private val shutdownWords = listOf("shut down", "power down", "power off", "goodbye", "stand down")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("J.A.R.V.I.S. standing by")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        tts.language = Locale.UK
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { if (stopping) stopSelf() else listen() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { if (stopping) stopSelf() else listen() } }
        })
        say("Systems online. Standing by.")
    }

    private fun say(text: String) {
        JarvisState.state.value = "SPEAKING"
        recognizer?.cancel()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    private fun listen() {
        JarvisState.state.value = if (awaitingCommand) "LISTENING" else "STANDBY"
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    handle(heard)
                }
                override fun onError(error: Int) {
                    awaitingCommand = false
                    main.postDelayed({ listen() }, 400)
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            )
        }
    }

    private fun handle(heard: String) {
        if (awaitingCommand) {
            awaitingCommand = false
            if (heard.isNotBlank()) ask(heard) else listen()
            return
        }
        val lower = heard.lowercase()
        if ("jarvis" !in lower) { listen(); return }   // wake word gate: everything else is ignored
        val command = lower.substringAfter("jarvis").trim(' ', ',', '.')
        if (command.isEmpty()) { awaitingCommand = true; say("Yes, sir?") } else ask(command)
    }

    private fun ask(text: String) {
        if (text.lowercase().trim(' ', '.') in shutdownWords) {
            stopping = true
            say("Powering down. Goodbye, sir.")
            return
        }
        JarvisState.state.value = "THINKING"
        scope.launch {
            val out = try { callBackend(text) } catch (e: Exception) { null }
            main.post {
                if (out == null) { say("I'm afraid I can't reach the server, sir."); return@post }
                val spoken = StringBuilder(out.getString("reply"))
                val acts = out.getJSONArray("actions")
                for (i in 0 until acts.length()) {
                    val a = acts.getJSONObject(i)
                    Actions.run(this@JarvisService, a.getString("name"), a.getJSONObject("args"))
                        ?.let { spoken.append(" ").append(it) }
                }
                say(spoken.toString())
            }
        }
    }

    private fun callBackend(text: String): JSONObject {
        val body = JSONObject().put("text", text)
            .put("apps", JSONArray(Actions.appLabels(this).take(200)))
            .toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder()
            .url("${Config.BASE_URL}/chat")
            .addHeader("Authorization", "Bearer ${Config.TOKEN}")
            .post(body).build()
        return http.newCall(req).execute().use { JSONObject(it.body!!.string()) }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        scope.cancel()
        JarvisState.state.value = "OFFLINE"
        super.onDestroy()
    }
}
