package com.example.jarvis

// Values are injected at build time (see app/build.gradle.kts and the GitHub secrets).
object Config {
    val BASE_URL: String = BuildConfig.BASE_URL
    val TOKEN: String = BuildConfig.TOKEN
}
