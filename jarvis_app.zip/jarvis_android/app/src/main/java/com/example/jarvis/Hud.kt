package com.example.jarvis

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.MutableStateFlow

object JarvisState { val state = MutableStateFlow("LOCKED") }

val Gold = Color(0xFFF5C542)
val GoldDim = Color(0xFF8A6D1A)

@Composable
fun Hud(onStop: () -> Unit = {}) {
    val state by JarvisState.state.collectAsState()
    val ms = when (state) { "THINKING" -> 1200; "LISTENING" -> 3000; "SPEAKING" -> 4000; else -> 9000 }
    val t = rememberInfiniteTransition(label = "spin")
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(ms, easing = LinearEasing)), label = "a")
    val pulse by t.animateFloat(0.85f, 1.1f, infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "p")

    Column(
        Modifier.fillMaxSize().background(Color(0xFF07060A)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Canvas(Modifier.size(300.dp)) {
            listOf(140f to 1f, 115f to -1f, 90f to 1f).forEach { (r, dir) ->
                val rr = r.dp.toPx()
                for (k in 0..2) {
                    drawArc(
                        color = Gold,
                        startAngle = dir * angle + k * 120f,
                        sweepAngle = 70f,
                        useCenter = false,
                        topLeft = Offset(center.x - rr, center.y - rr),
                        size = Size(rr * 2, rr * 2),
                        style = Stroke(width = 3.dp.toPx())
                    )
                }
            }
            drawCircle(Gold, radius = 34.dp.toPx() * pulse, center = center)
            drawCircle(Color(0xFFFFF4CC), radius = 16.dp.toPx() * pulse, center = center)
        }
        Spacer(Modifier.height(16.dp))
        Text("J.A.R.V.I.S.", color = Gold, fontSize = 22.sp)
        Text(state, color = GoldDim, fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
        TextButton(onClick = onStop) { Text("POWER OFF", color = GoldDim, fontSize = 12.sp) }
    }
}
