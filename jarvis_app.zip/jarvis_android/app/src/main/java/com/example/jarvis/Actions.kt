package com.example.jarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject

/** Everything Jarvis can do on the phone. run() returns null on success, or a sentence to speak. */
object Actions {
    // Jarvis refuses to tap anything that looks like money, sending, or deleting.
    private val SENSITIVE = Regex("pay|send|delete|buy|purchase|transfer|confirm|order|remove|uninstall", RegexOption.IGNORE_CASE)

    fun appLabels(ctx: Context): List<String> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null }
            .map { pm.getApplicationLabel(it).toString() }
            .sorted()
    }

    fun run(ctx: Context, name: String, args: JSONObject): String? = try {
        when (name) {
            "open_app" -> launch(ctx, args.getString("name"))
            "open_url" -> openUrl(ctx, args.getString("url"))
            "draft_email" -> draftEmail(ctx, args)
            "tap_text" -> tap(args.getString("text"))
            else -> "I don't know how to do that, sir."
        }
    } catch (e: Exception) {
        "That didn't work, sir."
    }

    private fun launch(ctx: Context, name: String): String? {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName) != null }
        val label = { a: android.content.pm.ApplicationInfo -> pm.getApplicationLabel(a).toString() }
        val match = apps.firstOrNull { label(it).equals(name, true) }
            ?: apps.firstOrNull { label(it).contains(name, true) }
            ?: return "I couldn't find $name, sir."
        ctx.startActivity(pm.getLaunchIntentForPackage(match.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return null
    }

    private fun openUrl(ctx: Context, url: String): String? {
        val uri = Uri.parse(url)
        if (uri.scheme != "http" && uri.scheme != "https") return "I only open web links, sir."
        ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return null
    }

    // Drafts only: you review the email and tap Send yourself.
    private fun draftEmail(ctx: Context, a: JSONObject): String? {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(a.getString("to")))
            .putExtra(Intent.EXTRA_SUBJECT, a.getString("subject"))
            .putExtra(Intent.EXTRA_TEXT, a.getString("body"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return null
    }

    private fun tap(text: String): String? {
        if (SENSITIVE.containsMatchIn(text)) return "I'll leave that one to you, sir."
        val svc = JarvisAccessibilityService.instance ?: return "Accessibility access isn't enabled, sir."
        return if (svc.tapText(text)) null else "I couldn't find $text on screen, sir."
    }
}
