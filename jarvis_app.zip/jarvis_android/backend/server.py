# Jarvis backend: keeps your Anthropic API key OFF the phone.
# Run:  JARVIS_TOKEN=<long random string> ANTHROPIC_API_KEY=<key> uvicorn server:app --port 8000
# Put it behind HTTPS (Cloudflare Tunnel, Render, Fly.io, etc). The phone refuses plain http.
import os, hmac, time
from collections import defaultdict
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
import anthropic

app = FastAPI()
client = anthropic.Anthropic()
TOKEN = os.environ["JARVIS_TOKEN"]
MODEL = "claude-sonnet-5-5"
SYSTEM = (
    "You are J.A.R.V.I.S., a polished, dry-witted British AI butler in the style of Age of Ultron. "
    "Address the user as 'sir' or 'ma'am'. Replies are spoken aloud: one or two short sentences, "
    "no markdown. Use tools to act on the phone. Emails are only drafted; the user taps Send. "
    "Never claim an action succeeded; the phone reports failures itself."
)
TOOLS = [
    {"name": "open_app", "description": "Launch an installed app by its name.",
     "input_schema": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}},
    {"name": "open_url", "description": "Open an http(s) link in the browser.",
     "input_schema": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}},
    {"name": "draft_email", "description": "Open an email draft in the mail app for the user to review and send.",
     "input_schema": {"type": "object", "properties": {
         "to": {"type": "string"}, "subject": {"type": "string"}, "body": {"type": "string"}},
         "required": ["to", "subject", "body"]}},
    {"name": "tap_text", "description": "Tap a button or item on the current screen by its visible text.",
     "input_schema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}},
]

hits = defaultdict(list)  # crude rate limit: 30 requests / minute


class Req(BaseModel):
    text: str
    apps: list[str] = []


@app.post("/chat")
def chat(req: Req, authorization: str = Header(default="")):
    if not hmac.compare_digest(authorization, f"Bearer {TOKEN}"):
        raise HTTPException(401)
    now = time.time()
    hits["me"] = [t for t in hits["me"] if now - t < 60]
    if len(hits["me"]) >= 30:
        raise HTTPException(429)
    hits["me"].append(now)

    r = client.messages.create(
        model=MODEL, max_tokens=300,
        system=SYSTEM + " Installed apps: " + ", ".join(req.apps[:200]),
        tools=TOOLS,
        messages=[{"role": "user", "content": req.text[:1000]}],
    )
    reply = "".join(b.text for b in r.content if b.type == "text")
    actions = [{"name": b.name, "args": b.input} for b in r.content if b.type == "tool_use"]
    return {"reply": reply or ("Right away, sir." if actions else "Sir?"), "actions": actions}
